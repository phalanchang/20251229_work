
  # Design Specification Document

  This is a code bundle for Design Specification Document. The original project is available at https://www.figma.com/design/UTP93hwGTGB2SJ7zbt1mur/Design-Specification-Document.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  